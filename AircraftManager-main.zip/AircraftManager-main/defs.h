#pragma once
#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR  256
#include "FH_Part.h"
#include "IT_Part.h"
#include "FHIT_Part.h"

#endif
